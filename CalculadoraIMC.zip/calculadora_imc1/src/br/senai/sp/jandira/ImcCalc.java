package br.senai.sp.jandira;

import java.util.Scanner;

public class ImcCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Qual é o seu nome?");
		Scanner teclado = new Scanner(System.in);
		
		String nome;
		nome = teclado.next();
		
		System.out.println("Qual é o seu peso?");
		Scanner peso = new Scanner(System.in);
		double kg;
		kg = peso.nextDouble();
		
		System.out.println("Qual a sua altura?");
		Scanner alt = new Scanner(System.in);
		double altu;
		altu =alt.nextDouble();
		
		double base;
		base = altu*altu;
		double imc = kg/base;
		
		System.out.println("Olá "+nome+" seu IMC é "+imc+"");

	}
    
}
   
